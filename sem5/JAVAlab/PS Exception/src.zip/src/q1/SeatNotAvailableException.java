package q1;

public class SeatNotAvailableException extends Exception {
    public SeatNotAvailableException(String str) {
        super(str);
    }
}
